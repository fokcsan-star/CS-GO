﻿from datetime import datetime
from typing import Dict, List, Optional
from abc import ABC, abstractmethod


class Person(ABC):
    def __init__(self, name: str, email: str):
        self.name = name
        self.email = email
        self.id = hash(f"{name}{email}{datetime.now()}")
    
    @abstractmethod
    def get_role(self) -> str:
        pass
    
    def display_info(self) -> str:
        return f"{self.name} ({self.email}) - {self.get_role()}"

class Student(Person): 
    def __init__(self, name: str, email: str):
        super().__init__(name, email)
        self.enrolled_courses: Dict[str, CourseProgress] = {}
        self.completed_courses: List[str] = []
    
    def get_role(self) -> str:
        return "student"
    
    def enroll_in_course(self, course_name: str):
        if course_name not in self.enrolled_courses:
            self.enrolled_courses[course_name] = CourseProgress(course_name)
            print(f"student {self.name} zacislen na kyrs : {course_name}")
        else:
            print(f"student yze zacislen na kyrs: {course_name}")
    
    def complete_assignment(self, course_name: str, assignment_name: str, grade: float):
        if course_name in self.enrolled_courses:
            self.enrolled_courses[course_name].add_assignment(assignment_name, grade)
        else:
            print(f"student ne zacislen na kyrs: {course_name}")

    def get_progress(self) -> Dict[str, float]:
        progress = {}
        for course_name, course_progress in self.enrolled_courses.items():
            progress[course_name] = course_progress.get_average_grade()
        return progress
    
    def display_progress(self):
        print(f"\nprogress studenta {self.name}:")
        for course_name, progress in self.enrolled_courses.items():
            print(f"  kyrs: {course_name}")
            print(f"  sredni bal: {progress.get_average_grade():.2f}")
            print(f"  proideno zadani: {len(progress.assignments)}")
            if progress.is_completed:
                print(f"  Statys: zavervon ✓")
               
               
class Instructor(Person):
    def __init__(self, name: str, email: str, department: str):
        super().__init__(name, email)
        self.department = department
        self.courses_taught: List[str] = []
    
    def get_role(self) -> str:
        return "prepodavatel"
    
    def assign_course(self, course_name: str):
        if course_name not in self.courses_taught:
            self.courses_taught.append(course_name)
            print(f"prepodavatel {self.name} naznacen na kyrs: {course_name}")
    
    def grade_student(self, student: Student, course_name: str, assignment_name: str, grade: float):
        if course_name in self.courses_taught:
            student.complete_assignment(course_name, assignment_name, grade)
            print(f"ocenka {grade} vistavlena studenty {student.name} za zadanie {assignment_name}")
        else:
            print(f"prepodavatel ne vedet kyrs: {course_name}")

class CourseProgress:
    def __init__(self, course_name: str):
        self.course_name = course_name
        self.assignments: Dict[str, float] = {}
        self.is_completed = False
    
    def add_assignment(self, assignment_name: str, grade: float):
        self.assignments[assignment_name] = grade
       
        if len(self.assignments) >= 5:
            self.is_completed = True
    
    def get_average_grade(self) -> float:
        if not self.assignments:
            return 0.0
        return sum(self.assignments.values()) / len(self.assignments)
    
    def get_total_assignments(self) -> int:
        return len(self.assignments)

class Course:
    def __init__(self, name: str, description: str, instructor: Optional[Instructor] = None):
        self.name = name
        self.description = description
        self.instructor = instructor
        self.students: List[Student] = []
        self.assignments: List[str] = []
    
    def add_student(self, student: Student):
        if student not in self.students:
            self.students.append(student)
            student.enroll_in_course(self.name)
    
    def add_assignment(self, assignment_name: str):
        if assignment_name not in self.assignments:
            self.assignments.append(assignment_name)
    
    def get_course_statistics(self) -> Dict:
        if not self.students:
            return {}
        
        vsego_studentov = len(self.students)
        zaverwili_count = 0
        ocenki = []
        
        for student in self.students:
            if self.name in student.enrolled_courses:
                progress = student.enrolled_courses[self.name]
                if progress.is_completed:
                    zaverwili_count += 1
                ocenki.append(progress.get_average_grade())
        
        return {
            'vsego_studentov': vsego_studentov,
            'zaverwili_count': zaverwili_count,
            'sredn_ocenka': sum(ocenki) / len(ocenki) if ocenki else 0,
            'kolichestvo_zadaniy': len(self.assignments)
        }
    
    def display_info(self):
        print(f"\nKyrs: {self.name}")
        print(f"Opisanie: {self.description}")
        if self.instructor:
            print(f"Prepodavatel: {self.instructor.name}")
        print(f"Zadaniy: {len(self.assignments)}")
        print(f"Studentov: {len(self.students)}")
        
class UniversitySystem:
    def __init__(self):
        self.students: Dict[int, Student] = {}
        self.instructors: Dict[int, Instructor] = {}
        self.courses: Dict[str, Course] = {}
    
    def add_student(self, name: str, email: str):
        student = Student(name, email)
        self.students[student.id] = student
        print(f"Dobavlen noviy student: {name}")
        return student
    
    def add_instructor(self, name: str, email: str, department: str):
        instructor = Instructor(name, email, department)
        self.instructors[instructor.id] = instructor
        print(f"Dobavlen noviy prepodavatel: {name}")
        return instructor
    
    def add_course(self, name: str, description: str, instructor_id: Optional[int] = None):
        instructor = None
        if instructor_id in self.instructors:
            instructor = self.instructors[instructor_id]
        
    